import numpy as np

# countsRoulette = { k: 0 for k in fitnessRanked.values() }
# countsRevRoulette = { k: 0 for k in fitnessRanked.values() }
# countsTourn = { k: 0 for k in fitnessRanked.values() }
#
# for i in range(0, 100):
#     resR = RouletteWheel(fitnessRanked)
#     resRR = Ranked(normalRanked)
#     resT = Tournament(normalRanked)
#
#     for pair in resR:
#         countsRoulette[pair[0]] += 1
#         countsRoulette[pair[1]] += 1
#
#     for pair in resRR:
#         countsRevRoulette[pair[0]] += 1
#         countsRevRoulette[pair[1]] += 1
#
#     for pair in resT:
#         countsTourn[pair[0]] += 1
#         countsTourn[pair[1]] += 1
#
# print(f"Raw Fitness (fitness, value): {fitnessRanked}")
# print(f"Ranked Organisms (rank, value): {normalRanked}")
# print()
# print(f"Roulette Wheel (organism, n times selected): {countsRoulette}")
# print(f"Ranking (organism, n times selected): {countsRevRoulette}")
# print(countsTourn)
# l1 = set(fitnessRanked)
# l2 = set(range(1, max(normalRanked.keys())+1))
# print(l1)
# print(l2)
# print(l1 == l2)

# result = []
#
# [result.extend(normalRanked[k]) for k in list(numpy.where(numpy.array(list(normalRanked.keys())) >= 3)[0])]
#
# print(result)

organisms = [('ab', 5), ('abb', 1), ('aa', 0.5)]

print(sorted([k for v, k in organisms]))
print(sorted(organisms, key=lambda x: x[1]))
